<!DOCTYPE html>
<html style="overflow-x:hidden">
  <head>
    <meta charset = "utf-8">
    <title>南工骁鹰|2021规则评测</title>
    <meta http-equiv = "X-UA-Compatible" content = "IE=Edge">
    <meta name = "viewport" content = "width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta name = "author" content = "Big_Uncle">
    <link rel = "icon" href = "robomaster.jpg">
    <link rel = "stylesheet" href = "bootstrap.min.css">
  </head>
  <body style="font-family:'微软雅黑';font-size:20px;background:url('background.jpg') repeat">
	<div style="position:fixed;left:0;right:0;background:white;z-index:99" id="time"></div>
    <div class="container" style="background:rgb(255,255,255,0.7)">
      <div class="jumbotron">
				<h1><center>RM2021 南工骁鹰 规则评测</center></h1>
        <small>本试题是从海量题库中随机抽取的50道题目，每道题均为单选题，每题两分，满分一百分，点击提交后可以查看分数，但并不会给出具体错误选项。要求各位最后得分在90分以上。</small>
			</div>
      <div class="form-group">
        <label for="exampleInputEmail1">你的姓名：</label>
        <input style="width:100px; display:inline" class="form-control" id="name" placeholder="姓名">
      </div><hr>
      <text>请完成下列选项：</text>
      <div>
		<?php
			$file_path = "questions.txt";
			$str = file_get_contents($file_path);
			$str = json_decode($str, true);
			$questions = $str["content"];
			$length = sizeof($questions);
			$arr = array();
			for($x = 0; $x < $length; $x++)
			{
				$arr[$x] = $x;
			}
			shuffle($arr);
			if($length >= 50)
				$length = 50;
			for($x = 0;$x < $length; $x++)
			{
				$question = $questions[$arr[$x]];
				echo "<text style='font-weight:bold'>".($x+1)."、".$question['title']."</text>";
				$Arr = array();
				for($j = 0; $j < 4; $j++)
				{
					$Arr[$j] = $j;
				}
				shuffle($Arr);
				for($j = 0; $j < 4; $j++)
				{
					echo '<div class="radio"><label><input type="radio" name="optionsRadios'.$x.'" value="'.($Arr[$j]+1).'" index="'.$arr[$x].'">'.$question[$Arr[$j]+1].'</label></div>';
				}

			}
		?>
      </div>
      <center><button type="submit" class="btn btn-primary" onclick="check()">提交</button></center><hr>
    </div>
  </body>
  <script src="jquery.min.js"></script>
  <script>
	function check()
	{
		var Name = document.getElementById("name").value;
		var data = new Array();
		if(Name == "")
		{
			alert("未填写姓名！");
			score = 0;
			return;
		}else{
			var user = new Object();
			user.name = Name;
			data.push(user);
			var radios = $("[type = 'radio']");
			for(var i = 0; i< radios.length; i++){
			  if(radios[i].checked){
				  var items = new Array();
				var item = new Object();
				item.index = radios[i].getAttribute("index");
				item.value = radios[i].value;
				items.push(item);
				data.push(items);
			  }
			}
			$.ajax({
				type: "post",
				url: 'score.php',
				data: {
					"answer": data
				},
				dataType: "json",
				success: function(data) {
					alert(data);
					window.location.reload();
				},
				error: function(data) {
					alert("出现错误！请截图发给谢胜  " + data);
					console.log(data);
				}
			});
		}
	}
	window.onload=clock;
	var shenyu=2400000;
	function clock(){
	  shenyu = shenyu - 500;//倒计时毫秒数
	  if(shenyu < 0)
	  {
		  alert("你的时间用完了！");
		  window.location.reload();
	  }
	  var shengyuM=parseInt(shenyu/(60*1000)),//除去天的毫秒数转换成分钟
		M=shenyu-shengyuM*60*1000;//除去天、小时、分的毫秒数
		S=parseInt((shenyu-shengyuM*60*1000)/1000)//除去天、小时、分的毫秒数转化为秒
		document.getElementById("time").innerHTML=("剩余时间："+shengyuM+"分"+S+"秒"+"<br>");
		// setTimeout("clock()",500);
	  setTimeout(clock,500);
	}
  </script>
</html>