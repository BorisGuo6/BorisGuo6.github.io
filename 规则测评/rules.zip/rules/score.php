<?php
	$answer = $_POST["answer"];
	$length = sizeof($answer);
	$score = 0;
	$find = 0;
	
	$file_path = "questions.txt";
	$str = file_get_contents($file_path);
	$str = json_decode($str, true);
	$questions = $str["content"];
	
	for($i = 1;$i<$length;$i++)
	{
		$value = $answer[$i][0]["value"];
		$index = $answer[$i][0]["index"];
		if($questions[$index]["asw"] == $value)
			$score += 2;
	}
	
	date_default_timezone_set('PRC');
	$now = strtotime('now');
	$ddl = strtotime('2020-11-23 00:00:00');
	$result = array();
	if($ddl - $now < 0)
	{
		$result[0] = "对不起，已经过了提交截止时间，你的分数将不会被录入数据库。你的最终得分是：".$score."分！";
		echo json_encode($result);
		return;
	}
	
	$file_path = "result.txt";
	$str = file_get_contents($file_path);
	$str = json_decode($str, true);
	foreach($str as $name=>$num)
	{
		if($answer[0]["name"] == $name)
		{
			$find = 1;
			if($num < $score)
			{
				$str[$answer[0]["name"]] = $score;
			}
		}
	}
	if($find == 0)
	{
		$str[$answer[0]["name"]] = $score;
	}
	file_put_contents($file_path, json_encode($str));

	$result[0] = "你的最终得分是：".$score."分！";
	echo json_encode($result);
?>