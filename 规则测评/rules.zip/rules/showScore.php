<!DOCTYPE html>
<html style="overflow-x:hidden">
  <head>
    <meta charset = "utf-8">
    <title>南工骁鹰|2020规则评测成绩</title>
    <meta name = "author" content = "Big_Uncle">
    <link rel = "icon" href = "robomaster.jpg">
  </head>
  <body>
<?php
	$file_path = "result.txt";
	$scores = file_get_contents($file_path);
	$scores = json_decode($scores, true);
	arsort($scores);
	echo "<table border='1'><tr><th>序号</th><th>姓名</th><th>分数</th></tr>";
	$id = 1;
	foreach($scores as $name=>$num)
	{
		echo "<tr><td>".$id."</td><td>".$name."</td><td>".$num."</td></tr>";
		$id = $id + 1;
	}
	echo "</table>";
?>
</body></html>